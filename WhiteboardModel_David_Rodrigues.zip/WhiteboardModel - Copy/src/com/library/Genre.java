package com.library;

public enum Genre {
    FANTASY, SCI_FI, NON_FICTION, FICTION, HISTORICAL, THRILLER, ACTION, ADVENTURE, MEMOIR
}
